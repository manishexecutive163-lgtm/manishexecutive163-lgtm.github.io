# Manish Sharma portfolio site

Everything in this folder goes into the root of the GitHub repository `Manish-Portfolio`.

```
index.html                 the whole website (all pages)
assets/brand/              logo marks, favicon, link-preview image
assets/dashboards/         the 19 dashboard screenshots
```

## Upload to GitHub (no coding needed)

1. Open https://github.com/manishexecutive163-lgtm/Manish-Portfolio
2. Click **Add file → Upload files**.
3. Drag in `index.html` and the whole `assets` folder (drag the folder itself so the sub-folders stay intact).
4. Scroll down and click **Commit changes**. The new `index.html` replaces the old one.
5. Wait 1–2 minutes, then open https://manishexecutive163-lgtm.github.io/Manish-Portfolio/

If the site doesn't update: Settings → Pages → Source should be "Deploy from a branch", branch `main`, folder `/ (root)`.

## Turn on the contact form (free, about 2 minutes)

The form sends messages to an email inbox through Web3Forms (free plan: 250 messages a month).

1. Go to https://web3forms.com and click **Create your Access Key**.
2. Enter `manishexecutive163@gmail.com`. An access key arrives in that inbox.
3. In GitHub, open `index.html` and click the pencil (Edit) icon.
4. Search for `const FORM_KEY='';` and paste the key between the quotes:
   `const FORM_KEY='paste-the-key-here';`
5. Click **Commit changes**.

Messages then land in Manish's inbox, and "Reply" goes straight to the person who filled in the form.
Until a key is added, the form still works: it prepares the message and opens the visitor's email app instead.

## Editing later

- Case study links: search `const DRIVE=` in `index.html`.
- Results text: search `const RESULTS=`.
- Tools list: search `const TOOLS=`.
